<?php $__empty_1 = true; $__currentLoopData = $wheels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wheel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="ww-avl-card col-md-4 my-2">
        <div class="card">
            <div  class="ww-card-tag">
            <span>Available Now</span>
            </div>
        
            <img style="height: 250px; width:310px"  src="<?php echo e(asset('assets/img/ww-pic.png')); ?>" alt="no img" class="img-fluid">
        
            <div class="card-body">
            <h5 class="card-title"><?php echo e($wheel->wheel_name); ?></h5>
            <p class="card-text">Last Cog Number: <?php echo e($wheel->wallet->count()); ?></p>
            <div class="pro-price">
                <h4>Cog Price : <span>US$<?php echo e($wheel->cog_price); ?></span></h4>
            </div> 
            <a href="<?php echo e(url('wheels_details?id=' .$wheel->id)); ?>" class="pro-dtl-btn">Join Wealth Wheel</a>

            <!-- <a href="<?php echo e(route('wheels_details', ['id' =>encrypt($wheel->id)])); ?>"  class="pro-dtl-btn">Join Wealth Wheel</a> -->
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <h3>No record found!</h3>
<?php endif; ?><?php /**PATH E:\xampp\htdocs\wealth-wheel\resources\views/user/filtered_wheel.blade.php ENDPATH**/ ?>