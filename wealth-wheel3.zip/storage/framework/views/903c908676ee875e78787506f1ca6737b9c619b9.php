
<?php $__env->startSection('user'); ?>
    active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('heading'); ?>
  Edit User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    MLM
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <main>
        <div class="content-body">


            <section id="column-selectors">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                            </div>

                            <div class="card-content">
                                <div class="card-body card-dashboard">

                                    <form action="<?php echo e(route('update',['user'=>$user->id])); ?>" id="validationForm" method="post">
                                        <?php echo csrf_field(); ?>

                                        <div class="form-group">
                                            <label for="exampleFormControlInput1">Name</label>
                                            <input type="text" value="<?php echo e($user->name); ?>" required class="form-control" name="name" placeholder="name">
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleFormControlInput1">Email</label>
                                            <input type="email" required value="<?php echo e($user->email); ?>" class="form-control" name="email"  placeholder="email">
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleFormControlInput1">phone</label>
                                            <input type="text" required value="<?php echo e($user->phone); ?>" class="form-control" name="phone"  placeholder="phone">
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleFormControlInput1">Password</label>
                                            <input type="password"  class="form-control" id="exampleFormControlInput1" name="password" placeholder="********">
                                        </div>


                                        <div class="form-group text-center">
                                            <button class="btn btn-success">save</button>
                                        </div>


                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\wealth-wheel\resources\views/dashboard/user/edit.blade.php ENDPATH**/ ?>