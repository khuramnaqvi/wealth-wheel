
<?php $__env->startSection('Withdraw'); ?>
    active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('heading'); ?>
    Withdraw List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    MLM
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <main>
        <div class="content-body">


            <section id="column-selectors">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                            </div>

                            <div class="card-content">
                                <div class="card-body card-dashboard">

                                    <div class="table-responsive">
                                        <table class="table table-striped dataex-html5-selectors">
                                            <thead>
                                            <tr>
                                                <th>#</th>
                                                <th scope="col">Username</th>
                                                <th scope="col">Amount</th>
                                                <th scope="col">Status</th>
                                                <th>Created AT</th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $count=1; ?>
                                            <?php $__currentLoopData = $withdraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($count++); ?></td>
                                                    <td><?php echo e($withdraw->userr->name); ?></td>
                                                    <td><?php echo e($withdraw->withdraw); ?></td>
                                                    <td><?php echo e($withdraw->status); ?></td>
                                                    <td><?php echo e(date($withdraw->created_at->format('Y-m-d'))); ?></td>

                                                    
                                                    
                                                    
                                                     
                                                    <td>
                                                        <?php if($withdraw->status=='pending'): ?>
                                                            <a href="<?php echo e(url('aprove_withdraw')); ?>/<?php echo e($withdraw->id); ?>">
                                                                <button class="btn btn-primary">Approve</button>
                                                            </a>
                                                            <?php else: ?>
                                                                <button class="btn btn-success">Approved</button>
                                                        <?php endif; ?>
                                                    </td> 
                                                </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            </tbody>

                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\wealth-wheel\resources\views/dashboard/withdraw/index.blade.php ENDPATH**/ ?>