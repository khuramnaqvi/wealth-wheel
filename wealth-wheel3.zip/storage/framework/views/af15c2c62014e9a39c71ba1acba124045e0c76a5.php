[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH E:\xampp\htdocs\wealth-wheel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>