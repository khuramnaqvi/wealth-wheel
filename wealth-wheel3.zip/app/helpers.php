<?php
use Illuminate\Support\Facades\Session;
  

function sesionclear(){

    Session::forget('cogpurchase'); 

}

   
