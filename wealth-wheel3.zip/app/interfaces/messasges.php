<?php

namespace App\Interfaces;

interface messasges {

    const userSave='user created successfully';
    const userDelete='user deleted successfully';
    const userupdate='user updated successfully';
    const wheelCreated='wealth wheel created successfully';
    const userLogin='User Login successfully';

   

    const Save='Record Save successfully';
    const Delete='Record deleted successfully';
    const Update='Record Updated successfully';

    const error='Some thing went wrong';

    const StatusUpdate='Status updated successfully';


}

